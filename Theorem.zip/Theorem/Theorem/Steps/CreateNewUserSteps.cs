﻿using System;
using TechTalk.SpecFlow;

namespace Theorem
{
    [Binding]
    public class CreateNewUserSteps
    {
        

        [Given(@"user landing on the home page")]
        public void GivenUserLandingOnTheHomePage()
        {
           // ScenarioContext.Current.Pending();
        }
        
        [Given(@"user start the signin button")]
        public void GivenUserStatTheSigninButton()
        {
           // ScenarioContext.Current.Pending();
        }
        
        [Then(@"get to new user register page")]
        public void ThenGetToNewUserRegisterPage()
        {
           // ScenarioContext.Current.Pending();
        }
        
        [Then(@"user get an error message")]
        public void ThenUserGetAnErrorMessage()
        {
           // ScenarioContext.Current.Pending();
        }
    }
}
