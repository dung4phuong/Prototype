﻿
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;


namespace Theorem
{
    public class PageElements
    {
        private readonly IWebDriver Driver;
        private const string PageUri = @"http://automationpractice.com/index.php";

        public PageElements(IWebDriver driver)
        {
            Driver = driver;
            PageFactory.InitElements(Driver, this);

        }

        //Signin page

        [FindsBy(How = How.Name, Using = "Sign in")]
        private IWebElement Signin;

        [FindsBy(How = How.Id, Using = "email")]
        private IWebElement email { get; set; }

        [FindsBy(How = How.Id, Using = "passwd")]
        private IWebElement password { get; set; }

        [FindsBy(How = How.Id, Using = "SubmitLogin")]
        private IWebElement SubmitLogin;

        [FindsBy(How = How.Id, Using = "email_create")]
        private IWebElement email_create;

        [FindsBy(How = How.Id, Using = "SubmitCreate")]
        private IWebElement SubmitCreate;
    //  start for register page
        [FindsBy(How = How.Id, Using = "id_gender1")]
        private IWebElement Mr;

        [FindsBy(How = How.Id, Using = "id_gender2")]
        private IWebElement Mrs;

        [FindsBy(How = How.Id, Using = "customer_firstname")]
        private IWebElement customer_firstname { get; set; }

        [FindsBy(How = How.Id, Using = "customer_lastname")]
        private IWebElement customer_lastname { get; set; }

        [FindsBy(How = How.Id, Using = "days")]
        private IWebElement days;

        [FindsBy(How = How.Id, Using = "months")]
        private IWebElement months;

        [FindsBy(How = How.Id, Using = "years")]
        private IWebElement years;

        [FindsBy(How = How.Id, Using = "newsletter")]
        private IWebElement newsletter;

        [FindsBy(How = How.Id, Using = "optin")]
        private IWebElement option;

        [FindsBy(How = How.Id, Using = "firstname")]
        private IWebElement firstname { get; set; }

        [FindsBy(How = How.Id, Using = "lastname")]
        private IWebElement lastname { get; set; }

        [FindsBy(How = How.Id, Using = "company")]
        private IWebElement company { get; set; }
            
        [FindsBy(How = How.Id, Using = "address1")]
        private IWebElement address { get; set; }

        [FindsBy(How = How.Id, Using = "city")]
        private IWebElement city { get; set; }

        [FindsBy(How = How.Id, Using = "id_state")]
        private IWebElement id_state;

        [FindsBy(How = How.Id, Using = "postcode")]
        private IWebElement postcode { get; set; }

        [FindsBy(How = How.Id, Using = "id_country")]
        private IWebElement country;

        [FindsBy(How = How.Id, Using = "phone_mobile")]
        private IWebElement phone_mobile { get; set; }

        [FindsBy(How = How.Id, Using = "alias")]
        private IWebElement Address_Alias { get; set; }
            
        [FindsBy(How = How.Id, Using = "submitAccount")]
        private IWebElement submitAccount;

        /*[FindsBy(How = How.Id, Using = "")]
        private IWebElement ;

        [FindsBy(How = How.Id, Using = "")]
        private IWebElement ;

        [FindsBy(How = How.Id, Using = "")]
        private IWebElement ;
            
        [FindsBy(How = How.Id, Using = "")]
        private IWebElement ;

        [FindsBy(How = How.Id, Using = "")]
        private IWebElement ;
        */


      
    }
    
}
