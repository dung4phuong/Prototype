﻿
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Theorem
{ 
    class Action
    {
        [TestFixture("Chrome")]
        [TestFixture("Firefox")]
        [TestFixture("InternetExplorer")]
        [Category("End-to-End")]
        [Parallelizable]
        [Description("")]
        class DemoTests
        {


            public void ApplicationHome()
            {
                using IWebDriver driver = new ChromeDriver();
                {
                    driver.Manage().Window.Maximize();
                    driver.Navigate().GoToUrl("http://automationpractice.com/index.php");

                }

            }





        }
    }
}
