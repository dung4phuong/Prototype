﻿Hello All


with this project i was lost side of the require and concentrate on the framewaork and all the ultility that need for it.

the framework that i was use are a combination of Selenium pageobject + specflow using C # visual studio. i ran out of time so i could not finish any require test after i re-read the direction

i hope this will help you to determind my technical skills set.....

the following package that i use was following:

selenium webdriver, selenium support packgae 
nunit and nlogger
specflow 

after load up the project you need to to update all package thru NUGet manager



thank you and looking for an opportunity to working with you and your team