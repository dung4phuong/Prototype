using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Collections.Generic;
using System.Net.Cache;

namespace Theorem
{ 
    [TestFixture("Chrome")]
    [TestFixture("Firefox")]
    [TestFixture("InternetExplorer")]
    [Category("End-to-End")]
    [Parallelizable]
    [Description("")]
    class DemoTests
    {
        #region BorrowerOpen
        public DemoTests(string browser)
        {
        }
        #endregion
        [SetUp]
        public void Setup()
        {
            using IWebDriver driver = new ChromeDriver();
            { 
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://automationpractice.com/index.php");

            }
            
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}